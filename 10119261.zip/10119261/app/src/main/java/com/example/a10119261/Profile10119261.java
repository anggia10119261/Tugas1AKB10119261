package com.example.a10119261;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Profile10119261 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile10119261);
    }
}