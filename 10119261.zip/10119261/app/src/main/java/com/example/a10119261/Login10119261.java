package com.example.a10119261;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Login10119261 extends AppCompatActivity {
    private Button btn_regis;
    private Button btn_login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login10119261);

        btn_regis = findViewById(R.id.btn_regis);
        btn_regis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent daftar = new Intent(Login10119261.this, Register10119261.class);
                startActivity(daftar);
            }
        });
        btn_login = findViewById(R.id.btn_login);
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent masuk = new Intent(Login10119261.this, MainActivity.class);
                startActivity(masuk);
            }
        });
    }
}