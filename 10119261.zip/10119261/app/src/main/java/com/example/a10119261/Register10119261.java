package com.example.a10119261;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Register10119261 extends AppCompatActivity {
    private Button btn_registrasi;
    private Button btn_backlogin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register10119261);

        btn_registrasi = findViewById(R.id.btn_registrasi);
        btn_registrasi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent registrasi = new Intent(Register10119261.this, MainActivity.class);
                startActivity(registrasi);
            }
        });
        btn_backlogin = findViewById(R.id.btn_backlogin);
        btn_backlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent backlogin = new Intent(Register10119261.this,Login10119261.class);
                startActivity(backlogin);
            }
        });
    }
}